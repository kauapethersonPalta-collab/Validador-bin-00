Validador BIN — versão para celular

1. Abra index.html no navegador.
2. Digite somente 6–8 números da BIN.
3. Toque em Consultar.

Importante:
- Não coloque número completo do cartão, validade, CVV ou código SMS.
- A BIN não permite determinar com certeza o método de verificação do Apple Wallet.
- O aplicativo consulta dados públicos de BIN e informa essa limitação.
